<?php
include "../koneksi.php";

$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$bstudi = $_POST['bstudi'];
$jammasuk = $_POST['jammasuk'];
$keterangan = $_POST['keterangan'];
$foto = $_FILES['foto']['name'];

$q = mysqli_query($con, "INSERT INTO absen_guru VALUES('','$nama', '$kelas', '$bstudi', '$jammasuk', '$keterangan', '$foto')");
echo "<script>window.alert('Berhasil Mengisi Absen')
    window.location='home.php'</script>";
if (strlen($foto) > 0) {
    if (is_uploaded_file($_FILES['foto']['tmp_name'])) {
        move_uploaded_file($_FILES['foto']['tmp_name'], "../TU/img/bukti guru/" . $foto);
    }
}
